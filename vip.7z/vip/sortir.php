<?php
session_start();
session_destroy();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sortint...</title>
    <meta http-equiv="refresh" content="2;url=/Jhugo3D-main/index.php">
</head>
<body>
<p>Has sortit de la sessio. Seras redirigit a la pagina principal...</p>
</body>
</html>